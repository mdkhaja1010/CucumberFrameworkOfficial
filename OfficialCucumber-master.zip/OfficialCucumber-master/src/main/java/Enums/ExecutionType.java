package Enums;

public enum ExecutionType {
    LOCAL,
    REMOTE
}
