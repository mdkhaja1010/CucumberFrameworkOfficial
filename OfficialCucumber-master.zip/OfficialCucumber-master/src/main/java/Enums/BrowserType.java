package Enums;

public enum BrowserType {

    CHROME,
    FIREFOX,
    EDGE,
    SAFARI
}
