package Enums;

public enum Values {
    min,
    max;
}
