package Enums;

public enum RunTimeData {

    TITLE;
}
